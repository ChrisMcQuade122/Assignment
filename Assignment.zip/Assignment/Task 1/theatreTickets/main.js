btnBook.addEventListener("click", bookTickets); 

function bookTickets() {

event.preventDefault()

let txt_name = document.getElementById("name");
let  txt_address1 = document.getElementById("address1");
let txt_address2 = document.getElementById("address2");
let txt_city = document.getElementById("city");
let txt_postcode = document.getElementById("postcode");



let cost;

let totalCost;
let discount;
let finalCost;

let ticket;
let ticketPrice;

const phantom = 79
const hamilton = 85
const lionKing = 67
const missSaigon = 83

switch (show.value) {
	case "phantom":
		cost = phantom * parseInt(seats.value);
		break;
	case "hamilton":
		cost = hamilton * parseInt(seats.value);	
		break;
	case "lionKing":
		cost = lionKing * parseInt(seats.value);
	break;
		case "missSaigon":
		cost = missSaigon * parseInt(seats.value);
}

if (seats.value >= 6) {
	cost = cost * 0.9;
}
else if (seats.value >= 10) {
	cost = cost * 0.85;
}

switch (delivery.value) {
	case "eTicket":
		ticket = "E-Ticket";
		ticketPrice = "Free";
		finalCost = cost;
		break;
	case "boxOffice":
		ticket = "Box Office";	
		ticketPrice = "£1.50";
		finalCost = cost + 1.50;
		break;
	case "post":
		ticket = "Posted";
		ticketPrice = "£3.99";
		finalCost = cost + 3.99;
}

document.getElementById("output");
output.innerText = "Name:\n" + txt_name.value + "\n\n" + 
"Address Line 1:\n" + txt_address1.value + "\n\n" + 
"Address Line 2:\n" + txt_address2.value + "\n\n" +
"City:\n" + txt_city.value + "\n\n" + 
"Postcode:\n" + txt_postcode.value + "\n\n" +
"Show:\n" + show.value + "\n\n" +
"Seats:\n" + seats.value + "\n\n" +
"Delivery Option:\n" + ticket + "\n\n" + 
"Final Cost:\n" + "£" + finalCost.toFixed(2);

}

