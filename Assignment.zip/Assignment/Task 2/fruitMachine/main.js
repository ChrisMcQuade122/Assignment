//Getting IDs
const image1 = document.getElementById("img1");
const image2 = document.getElementById("img2");
const image3 = document.getElementById("img3");
const txtMsg = document.getElementById("msg");
const txtCredit = document.getElementById("creditNum");
const txtWins = document.getElementById("winsNum");

//Getting buttons
const btnCredit = document.getElementById("btnCredit");
const btnSpin = document.getElementById("btnSpin");
const btnCollect = document.getElementById("btnCollect");

//Adding event listeners 
btnSpin.addEventListener("click", spin);
btnCredit.addEventListener("click", addCredit);
btnCollect.addEventListener("click", collect);

//Disabling input on spin and collect/Setting default values
btnSpin.disabled = true;
btnCollect.disabled = true;
let creditScore = "0";
let winsScore = "0";

//Setting credit/wins default
txtCredit.innerText="No Credit";
txtWins.innerText="No Winnings";

//Random image selector 
ranImgs();
function ranImgs() {
    ranNum1 = Math.round(Math.random() *7);
    image1.src = "img/slot" + ranNum1 + ".png";
    ranNum2 = Math.round(Math.random() *7);
    image2.src = "img/slot" + ranNum2 + ".png";    
    ranNum3 = Math.round(Math.random() *7);
    image3.src = "img/slot" + ranNum3 + ".png";    
}

//Add credit function 
function addCredit() {
    event.preventDefault();
    creditScore++;
    txtCredit.innerText = creditScore;
    btnSpin.disabled = false;
}

//Spin reels function, adds 5/10 depending on reel lineup 
function spin() {
    event.preventDefault()
    ranImgs()
    creditScore--;
    txtCredit.innerText = creditScore;
    txtMsg.innerText = "No Winning Reel"

    if (creditScore == 0) {
        btnSpin.disabled = true;
    }
    if (image1.src === image2.src && image1.src === image3.src) {
        winsScore += 9;
        txtWins.innerText = ++winsScore;
        txtMsg.innerText = "Jackpot! You won 10 coins!";
        btnCollect.disabled = false;
    }
    else if (image2.src === image3.src) {
        winsScore += 4;
        txtWins.innerText = ++winsScore;
        txtMsg.innerText = "Nice! You just won 5 coins!";
        btnCollect.disabled = false;
    }
}

//Collect credit function returing winnings to default 
function collect(){
    btnCollect.disabled = true;
    event.preventDefault();
    winsScore = "No Credit";
    txtMsg.innerText = "Coins Collected"

    txtWins.innerText = winsScore;

}